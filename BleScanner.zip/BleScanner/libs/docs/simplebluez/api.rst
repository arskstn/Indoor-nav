=============
API Reference
=============

Examples
========

To learn how to use SimpleBluez, please refer to the `examples`_ provided
in the repository.


.. Links

.. _examples: https://github.com/OpenBluetoothToolbox/SimpleBLE/tree/main/examples/simplebluez