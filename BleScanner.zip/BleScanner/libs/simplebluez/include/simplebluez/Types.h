#pragma once

#include <string>

namespace SimpleBluez {

typedef std::string ByteArray;

}
